// 👉 Aquí pega el código de tu curso (CursoSMC.jsx que ya tienes)
