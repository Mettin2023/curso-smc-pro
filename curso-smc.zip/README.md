# Curso Smart Money Concepts (SMC)

Este es un curso completo en español sobre **Smart Money Concepts (SMC)**, creado con **React + Vite**.

## 🚀 Cómo correr el proyecto

```bash
npm install
npm run dev
```

## 📤 Cómo desplegar en GitHub Pages

```bash
npm run build
npm run deploy
```

La página quedará publicada en:  
👉 https://TU_USUARIO.github.io/curso-smc
