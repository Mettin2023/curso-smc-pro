import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// ⚠️ CAMBIA "TU_USUARIO" por tu usuario de GitHub
export default defineConfig({
  plugins: [react()],
  base: "/curso-smc/"
})